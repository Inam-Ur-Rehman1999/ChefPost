document.addEventListener("DOMContentLoaded", function() {
    var container = document.getElementById('container');
    var slider = document.getElementById('slider');
    var slides = document.getElementsByClassName('slide').length;
    var buttons = document.getElementsByClassName('btn');
    
    var currentPosition = 0;
    var currentMargin = 0;
    var slidesPerPage = 0;
    var slidesCount = slides - slidesPerPage;
    var containerWidth = container.offsetWidth;
    var prevKeyActive = false;
    var nextKeyActive = true;

    window.addEventListener("resize", checkWidth);

    function checkWidth() {
        containerWidth = container.offsetWidth;
        setParams(containerWidth);
    }

    function setParams(w) {
        if (w < 551) {
            slidesPerPage = 1;
        } else if (w < 901) {
            slidesPerPage = 2;
        } else if (w < 1101) {
            slidesPerPage = 3;
        } else {
            slidesPerPage = 4;
        }
        slidesCount = slides - slidesPerPage;
        if (currentPosition > slidesCount) {
            currentPosition -= slidesPerPage;
        };
        currentMargin = -currentPosition * (100 / slidesPerPage);
        slider.style.marginLeft = currentMargin + '%';
        if (currentPosition > 0) {
            buttons[0].classList.remove('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons[1].classList.remove('inactive');
        }
        if (currentPosition >= slidesCount) {
            buttons[1].classList.add('inactive');
        }
    }

    setParams();

    // Make the functions accessible globally
    window.slideRight = function() {
        if (currentPosition != 0) {
            slider.style.marginLeft = currentMargin + (100 / slidesPerPage) + '%';
            currentMargin += (100 / slidesPerPage);
            currentPosition--;
        };
        if (currentPosition === 0) {
            buttons[0].classList.add('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons[1].classList.remove('inactive');
        }
    }

    window.slideLeft = function() {
        if (currentPosition != slidesCount) {
            slider.style.marginLeft = currentMargin - (100 / slidesPerPage) + '%';
            currentMargin -= (100 / slidesPerPage);
            currentPosition++;
        };
        if (currentPosition == slidesCount) {
            buttons[1].classList.add('inactive');
        }
        if (currentPosition > 0) {
            buttons[0].classList.remove('inactive');
        }
    }
});


// ------------Second Slider------------

document.addEventListener("DOMContentLoaded", function() {
    var container1 = document.getElementById('container1');
    var slider1 = document.getElementById('slider1');
    var slides = document.getElementsByClassName('slide').length;
    var buttons1 = document.getElementsByClassName('btn1');
    
    var currentPosition = 0;
    var currentMargin = 0;
    var slidesPerPage = 0;
    var slidesCount = slides - slidesPerPage;
    var containerWidth1 = container1.offsetWidth;
    var prevKeyActive = false;
    var nextKeyActive = true;

    window.addEventListener("resize", checkWidth);

    function checkWidth() {
        containerWidth1 = container1.offsetWidth;
        setParams(containerWidth1);
    }

    function setParams(w) {
        if (w < 551) {
            slidesPerPage = 1;
        } else if (w < 901) {
            slidesPerPage = 2;
        } else if (w < 1101) {
            slidesPerPage = 3;
        } else {
            slidesPerPage = 4;
        }
        slidesCount = slides - slidesPerPage;
        if (currentPosition > slidesCount) {
            currentPosition -= slidesPerPage;
        };
        currentMargin = -currentPosition * (100 / slidesPerPage);
        slider1.style.marginLeft = currentMargin + '%';
        if (currentPosition > 0) {
            buttons1[0].classList.remove('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons1[1].classList.remove('inactive');
        }
        if (currentPosition >= slidesCount) {
            buttons1[1].classList.add('inactive');
        }
    }

    setParams();

    // Make the functions accessible globally
    window.slideRight1 = function() {
        if (currentPosition != 0) {
            slider1.style.marginLeft = currentMargin + (100 / slidesPerPage) + '%';
            currentMargin += (100 / slidesPerPage);
            currentPosition--;
        };
        if (currentPosition === 0) {
            buttons1[0].classList.add('inactive');
        }
        if (currentPosition < slidesCount) {
            buttons1[1].classList.remove('inactive');
        }
    }

    window.slideLeft1 = function() {
        if (currentPosition != slidesCount) {
            slider1.style.marginLeft = currentMargin - (100 / slidesPerPage) + '%';
            currentMargin -= (100 / slidesPerPage);
            currentPosition++;
        };
        if (currentPosition == slidesCount) {
            buttons1[1].classList.add('inactive');
        }
        if (currentPosition > 0) {
            buttons1[0].classList.remove('inactive');
        }
    }
});


// ------------Carousel Slider------------
const willLeftLessThan40pxToScrollEnd = (nextStep) => {
    const scrollLeftAfterTwoClicks = carousel.scrollLeft + (nextStep*2)
    return scrollLeftAfterTwoClicks > carousel.scrollWidth - 40
}

const willLeftLessThan40pxToScrollStart = (nextStep) => {
    const scrollLeftAfterOneClick = carousel.scrollLeft - nextStep
    return scrollLeftAfterOneClick < 40
}

const handleClickGoAhead = () => {
    let nextStep = carousel.offsetWidth
    if(willLeftLessThan40pxToScrollEnd(nextStep)) nextStep *= 2

    carousel.scroll({
      left: carousel.scrollLeft + nextStep,
      behavior: "smooth"
    })
}

const handleClickGoBack = () => {
    let nextStep = carousel.offsetWidth
    if(willLeftLessThan40pxToScrollStart(nextStep)) nextStep *= 2
    
    carousel.scroll({
      left: carousel.scrollLeft - nextStep,
      behavior: "smooth"
    })
}
